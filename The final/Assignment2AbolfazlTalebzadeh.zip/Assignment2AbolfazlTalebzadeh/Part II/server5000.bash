export FLASK_APP=1.py
export FLASK_ENV=development
export FLASK_RUN_PORT=5000
flask run
