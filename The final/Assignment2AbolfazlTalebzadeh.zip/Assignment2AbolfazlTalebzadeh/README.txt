---------
contents:
---------
+Part I
 +__pychache__
 -SDES.cpython-38.pyc
 -DH.py
 -SDES.py
 -1.txt
 -2.txt
+Part II
 +__pychache__
 -SDES.cpython-38.pyc
 +templates
  -index.html
  -apply.html
  -chatbox.html
 -1.py
 -DH.py
 -SDES.py
 -80.bat
 -5000.bat
 -server80.bash
 -server5000.bash
------------------------------------------------------------
To run the program you need to have these installed: 
python 3.8.3  
Flask 1.1.2
Werkzeug 1.0.1
python collections library
requests library
sockets library
simple-websocket library
Flask-SocketIO library
-----------------------------------
***please do not replace the files***
-----------------------------------
A short tip to run part I:
-just execute the DH.py in an editor of choice (VScode, Pycharm, ...)
-SDES.py is a class which is called in DH.py and doesn't need to be executed
------------------------------------
A short tip to run part II:
on windows:
-run the batch files 80.bat and 5000.bat
on mac/linux:
-run the batch files server80.bash and server5000.bash
the remaining is the same on both OS
-open two web browser pages enter "htt://127.0.0.1:5000" in the address bar of the first one
-and enter "htt://127.0.0.1:80" into the other one
-write different names in the textbox for each page and hit submit
-enter 80 for the page open in 5000 and 5000 for the page opened in 80
- the chat page opens and everything is ready to talk
-for observing the encryptde messages you can refer to the server pages
